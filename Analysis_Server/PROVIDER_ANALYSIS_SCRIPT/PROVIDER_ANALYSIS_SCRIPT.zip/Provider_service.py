'''
    기본 제공형 스크립트 패키지
'''
import queue
from typing import Optional
import base64
'''
    [ FILE ] 타입 스크립트 모음
'''
import _Analysis_Server_.PROVIDER_ANALYSIS_SCRIPT.scripts.YARA.YARA as YARA


'''
    [ NETWORK ] 타입 스크립트 모음
'''
from _Analysis_Server_.PROVIDER_ANALYSIS_SCRIPT.scripts.URLhaus.urlhaus import URLhaus_for_provider


''' 
    [ REGISTRY ] 타입 스크립트 모음
'''


class Provider_Analysis_service:
    def __init__(self):
        self.YARA = YARA.Yara_Analyzer() # 야라 도구 제공
        self.URLhaus = URLhaus_for_provider()# URLhaus 제공

    def Yara_Analysis(self, analysis_target_bin: bytes)->queue.Queue:
        #  외부 스크립트가 해당 Yara 분석을 요구하고 있음
        return self.YARA.Start_Analysis(analysis_target_bin) # 비동기 분석 요청이므로 큐를 반환

    def URLhaus_Analysis(self, analysis_target_IP:str)->queue.Queue:
        return self.URLhaus.Start_Analysis(analysis_target_IP) # 비동기 분석 요청이므로 큐를 반환

    def BASE64_to_Binary(self, BASE64_data:str)->Optional[bytes]:
        try:
            return base64.b64decode(BASE64_data)
        except:
            return None