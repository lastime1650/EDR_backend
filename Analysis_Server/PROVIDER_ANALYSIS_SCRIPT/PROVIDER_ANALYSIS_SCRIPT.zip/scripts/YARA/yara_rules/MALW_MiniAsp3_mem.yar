rule MiniAsp3_mem : memory { 
  meta: author = "chort (@chort0)"
  description = "Detect MiniASP3 in memory"
  strings: 
    $pdb = "MiniAsp3\\Release\\MiniAsp.pdb" fullword 
    $httpAbout = "http://%s/about.htm" fullword 
    $httpResult = "http://%s/result_%s.htm" fullword 
    $msgInetFail = "open internet failed…" fullword 
    $msgRunErr = "run error!" fullword 
    $msgRunOk = "run ok!" fullword
    $msgTimeOutM0 = "time out,change to mode 0" fullword 
    $msgCmdNull = "command is null!" fullword 
condition:
  ($pdb and (all of ($http*)) and any of ($msg*))
  }
  
