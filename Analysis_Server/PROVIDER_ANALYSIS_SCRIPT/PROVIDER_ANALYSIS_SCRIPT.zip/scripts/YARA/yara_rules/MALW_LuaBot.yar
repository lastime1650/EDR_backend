rule LuaBot : MALW
{
        meta:
                description = "LuaBot"
                author = "Joan Soriano / @joanbtl"
                date = "2017-06-07"
                version = "1.0"
                MD5 = "9df3372f058874fa964548cbb74c74bf"
                SHA1 = "89226865501ee7d399354656d870b4a9c02db1d3"
                ref1 = "http://blog.malwaremustdie.org/2016/09/mmd-0057-2016-new-elf-botnet-linuxluabot.html"

        strings:
                $a = "LUA_PATH"
                $b = "Hi. Happy reversing, you can mail me: luabot@yandex.ru"
                $c = "/tmp/lua_XXXXXX"
                $d = "NOTIFY"
                $e = "UPDATE"

        condition:
                all of them
}
