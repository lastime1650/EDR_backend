from typing import Optional, Dict

import requests



class ThreatMiner:
    def __init__(self):
        self.main_url = 'https://api.threatminer.org/v2/'

    def Get_Domain_Info(self, Domain:str)->Optional[Dict]:

        Indicator_type = "domain"

        Output = {
            "whois":None,
            "passive_dns":None,
            "example_query_uri":None,
            "related_samples":None,
            "subdomains":None,
            "report_tagging":None
        }
        available_rt = ["whois","passive_dns", "example_query_uri", "related_samples", "subdomains", "report_tagging"]
        for i, rt in enumerate(available_rt):
            Output[rt] = self.Query_All_in_one(Indicator_type, Domain, i+1)

        return Output

    def Get_IP_Info(self, IP:str)->Optional[Dict]:
        Indicator_type = "host"
        Output = {
            "whois":None,
            "passive_dns":None,
            "uris":None,
            "related_samples":None,
            "ssl_certification":None,
            "report_tagging":None
        }
        available_rt = ["whois", "passive_dns", "uris", "related_samples", "ssl_certification", "report_tagging"]
        for i, rt in enumerate(available_rt):
            Output[rt] = self.Query_All_in_one(Indicator_type, IP, i+1)

        return Output


    def Query_All_in_one(self, Indicator_type:str, q:str, rt:int)->Optional[Dict]:
        get_req_url = self.make_full_url(Indicator_type, q, rt)
        r = self.Query(get_req_url)
        if self.valid_response(r):
            return r["results"][0]
        else:
            return None

    def Query(self, full_url:str)->dict:
        response = requests.get(full_url).json()
        print(response)
        return response

    def make_full_url(self, Indicator_type:str, q:str, rt:int)->str:
        full_url = f"{self.main_url}{Indicator_type}.php?q={q}&rt={rt}"
        return full_url

    def valid_response(self, query_result:dict)->bool:
        if "status_code" in query_result:

            if query_result["status_code"] == "200":
                return True
            else:
                return False
        else:
            return False

ThreatMiner().Get_IP_Info("8.8.8.8")